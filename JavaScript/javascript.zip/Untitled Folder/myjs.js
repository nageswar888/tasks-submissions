function myFunction() {
  setTimeout(function () {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
 var userdata = JSON.parse(this.responseText);
var table = document.getElementById("mytable");
for(var i=0 ;i<userdata.length;i++){
var row = table.insertRow(-1);
var Id=userdata[i].id;
document.getElementById("demo").innerHTML="";
 row.innerHTML= "<table><tr><td>"+userdata[i].id+"</td><td>"+userdata[i].name+"</td><td>"+userdata[i].username+"</td><td>"+userdata[i].email+" </td><td><a href=file:///home/sk-18/Desktop/HTML,CSS,JScript/details.html?id="+userdata[i].id+">button"+(i+1)+"</a></td></tr></table>"
	}	
	}
  };
  xhttp.open("GET", "https://jsonplaceholder.typicode.com/users", true);
  xhttp.send();
}, 2000);
} 
